# Signal Scope for FM-DX-Webserver

![Release](https://img.shields.io/github/v/release/fmatic/BroadcastMeter?display_name=tag&style=flat-square)
![Platform](https://img.shields.io/badge/platform-browser-green?style=flat-square)
![Version](https://img.shields.io/badge/version-0.5.0-00c8ff?style=flat-square)
[![Support my work](https://img.shields.io/badge/Support-My%20Work-333333?style=flat-square&logo=buymeacoffee&logoColor=white)](https://buymeacoffee.com/jannedx)


![Broadcast Meter Demo](docs/IMG_5472.GIF)

Signal Scope is a modern RF signal and audio modulation meter plugin for FM-DX-Webserver.

It combines broadcast-style metering, stereo/RDS indicators and customizable visual themes into a lightweight native-looking plugin.

## Features

- Real-time RF signal meter
- Real-time audio modulation meter
- Peak hold indicators
- Stereo / Mono / RDS / CLIP LEDs
- Multiple meter styles
- Theme system
- Native FM-DX-Webserver visual integration
- Compact and lightweight
- Mobile friendly
- Settings popup UI
- Update notification support

## Meter Styles

- Classic
- Segmented
- LED
- Thin
- Neon

## Themes

- Webserver Theme
- Matrix Green
- DX Green
- Amber Orange
- Arctic Cyan
- Nightwish Purple

## Installation

1. Download the latest release ZIP
2. Extract the `SignalScope` folder
3. Copy the folder into your FM-DX-Webserver plugins directory
4. Restart FM-DX-Webserver
5. Enable the plugin from Plugin Management

## Settings

Signal Scope includes a built-in settings popup accessible from the gear icon.

Current settings:

- Theme selection
- Meter style selection

Settings are stored locally in browser localStorage.

## LocalStorage Keys

```js
SIGNAL_SCOPE_THEME
SIGNAL_SCOPE_METER_STYLE
```

Example:

```js
localStorage.setItem('SIGNAL_SCOPE_THEME', 'matrixGreen');
localStorage.setItem('SIGNAL_SCOPE_METER_STYLE', 'neon');
location.reload();
```

## Supported Themes

```txt
webserver
matrixGreen
dxGreen
amberOrange
arcticCyan
nightwishPurple
```

## Supported Meter Styles

```txt
classic
segmented
led
thin
neon
```

## What's Nse

v0.5.3
 
- Glow intensity modes
- Peak Hold speed control
- Glass panel mode
- Mini / Normal / XL panel sizes
- Smooth LED fade animations
- Improved settings panel UI
- Neon and segmented meter improvements
- Better theme transitions
- Enhanced visual polish

Improved:
- Meter rendering performance
- Peak hold visibility
- Theme persistence
- Responsive layout handling


## Roadmap

### v0.5.3

- Animated theme transitions
- Optional glass panel
- Optional stronger glow
- Compact XL / Mini modes
- Peak hold speed control
- LED brightness control

## Future Ideas

- Vertical mode
- Retro tuner skin
- Analog needle mode
- Oscilloscope waveform mode
- Stereo image meter

## Credits

Special thanks to the FM-DX-Webserver community for ideas, testing and feedback.

## License

MIT License

## Author

Janne Heinikangas / JanneDX
Developed in Finland 🇫🇮

GitHub:
https://github.com/fmatic/SignalScope
